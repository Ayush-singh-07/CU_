package com.java.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginDao {
	public boolean check(String name, String password)  {
		
		try {
			Class.forName("org.postgresql.Driver");
			final String DB_URL="jdbc:postgresql://127.0.0.1:5432/javacrud";
			final String user="postgres";
			final String pass="12345";
			String sql="select * from users where name =? and  password= ?";

			
			Connection con = DriverManager.getConnection(DB_URL,user,pass);
			
			
			PreparedStatement st= con.prepareStatement(sql);
			st.setString(1, name);
			st.setString(2, pass);
			
			ResultSet rs = st.executeQuery();
			if(rs.next()) {
				return true;
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return false;
		
	}
}
