from django import forms
from .models import  Student

class myform(forms.ModelForm):
    # specify the name of model to use
    class Meta:
        model = Student
        fields = "__all__"