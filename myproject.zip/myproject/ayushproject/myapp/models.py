from django.db import models

# Create your models here.
class Student(models.Model):
    uid=models.IntegerField()
    fname=models.CharField(max_length=50)
    lname=models.CharField(max_length=50)
    email=models.CharField(max_length=50)
    passwd=models.CharField(max_length=50)