from django.urls import path
from . import views


urlpatterns = [
    path('', views.home, name="home"),
    path('insertStudents/', views.insert, name="insert"),
    path('view/', views.view, name="view"),
    path('fetch/', views.fetch, name="fetch"),
]
