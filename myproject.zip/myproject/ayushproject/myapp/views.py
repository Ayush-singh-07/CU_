from django.http import HttpResponse
from django.shortcuts import render
from datetime import datetime
from .forms import myform
from django.contrib import messages
from .models import *


# Create your views here.
def home(request):
    x = datetime.now()
    context = {'time': x}
    return render(request, 'index.html', context)


def insert(request):
    form = myform()
    if request.method == 'POST':
        form = myform(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Data Is Saved Successfully !')
        else:
            messages.error(request, 'Please Fill the form correctly !')
    context = {'form': form}
    return render(request, 'insertdata.html', context)


def view(request):
    data = Student.objects.all()
    return render(request, 'view.html', {'data': data})


def fetch(request):
    if request.method == 'POST':
        uid=request.POST['uid']
        data=Student.objects.all().filter(uid=uid)
        return render(request , 'fetch.html' , {'data':data})
    return render(request, 'fetch.html')
